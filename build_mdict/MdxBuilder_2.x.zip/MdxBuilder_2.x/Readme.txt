example.txt            		// MDict compact format example file
example_style.txt      		// MDict compact format style file (for use with example.txt)
manual_Chn.txt         		// Explaination of supported formats (Chinese)
manual_Eng.txt         		// Explaination of supported fomrats (English)
Readme.txt             		// This file
style_kdict.txt        		// Sytle file for use with decoded kdict file
style_sgd.txt          		// Style file for use with Sugar dict file
MdxBuilder.exe			// Mdx file builder
MdxStyler.exe			// A command line tool for replace style format in mdx file without repack the file.